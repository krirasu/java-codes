package com.capgemini.apply.service;

import com.capgemini.apply.bean.ApplicationBean;
import com.capgemini.apply.exception.ApplicationException;


public interface ApplyService 
{
	public int addApplicantDetails(ApplicationBean applicant) throws ApplicationException;
	public ApplicationBean getApplicationDetails(long applicationID) throws ApplicationException;
	public boolean isValidApplicatnt(ApplicationBean applicant) throws ApplicationException;

}

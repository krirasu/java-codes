package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Login;
import com.cg.service.LoginService;
import com.cg.service.LoginServiceImpl;

@WebServlet("/ValidateServlet")
public class ValidateServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    LoginService logService=null;   
	
	
    public ValidateServlet() 
    {
        super();
    }

    public void init(ServletConfig config) throws ServletException 
    {
    	System.out.println("Init block of validate servlet");
    }

	public void destroy() 
	{
    	System.out.println("Destroy block of validate servlet");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String uName=request.getParameter("txtUName");
		String uPwd=request.getParameter("txtPwd");
		logService= new LoginServiceImpl();
		PrintWriter pw=null;
		 pw = response.getWriter();

		try
		{
			Login usr=logService.getUserByUnm(uName);
			if(usr.getUserName().equalsIgnoreCase(uName)&&(usr.getPassword().equalsIgnoreCase(uPwd)))
			{
				 pw.println("Congratulations! You are a valid user");
			}
			else
			{
				pw.println("Sorry! You are not a valid user.");
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}

}

package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil 
{
	public static Connection getConn() throws SQLException
	{
		Connection conn = null;
		conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		return conn;
	}
	
	
}

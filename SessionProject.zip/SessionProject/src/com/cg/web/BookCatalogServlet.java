package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BookCatalogServlet")
public class BookCatalogServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public BookCatalogServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	
	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		pw.println("<body bgcolor='pink'>");
		pw.println("<h1>Select Book</h1>");
		pw.println("<form action='/SessionProject/CartServlet'>");
		pw.println("<select name='txtBook'>");
		pw.println("<option value='java'>Java</option>");
		pw.println("<option value='C'>C</option>");
		pw.println("<option value='oracle'>Oracle</option>");
		pw.println("<option value='html'>Html</option>");
		pw.print("</select>");
		pw.println("<input type='submit' value='Add to Cart' name='btnAddCart/>'");
		pw.println("</form>");
		pw.println("</body>");

	
	
	}

}

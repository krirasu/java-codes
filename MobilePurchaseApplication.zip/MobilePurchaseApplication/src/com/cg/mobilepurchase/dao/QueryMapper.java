package com.cg.mobilepurchase.dao;

public interface QueryMapper
{
	String SELECT_ALL_MOBILES="SELECT mobileId,name,price,quantity FROM mobiles";
	String SELECT_MOBILE="SELECT mobileId,name,price,quantity FROM mobiles where mobileId=?";
	String SELECT_SEQUENCE="SELECT purc_seq.NEXTVAL FROM DUAL";;
	String INSERT_QUERY="INSERT INTO purchasedetails VALUES(?,?,?,?,?,?)";
}

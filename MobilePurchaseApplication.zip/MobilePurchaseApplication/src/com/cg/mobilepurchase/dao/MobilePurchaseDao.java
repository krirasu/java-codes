package com.cg.mobilepurchase.dao;

import java.util.List;

import com.cg.mobilepurchase.dto.Mobiles;
import com.cg.mobilepurchase.dto.PurchaseDetails;
import com.cg.mobilepurchase.exception.MobileException;

public interface MobilePurchaseDao
{
	List<Mobiles> getAllMobiles() throws MobileException;
	Mobiles getMobile(long mid)throws MobileException;
	long insertPurchaseDetails(PurchaseDetails pDetails)throws MobileException;

}

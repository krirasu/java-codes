package com.cg.mobilepurchase.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mobilepurchase.dto.Mobiles;
import com.cg.mobilepurchase.dto.PurchaseDetails;
import com.cg.mobilepurchase.exception.MobileException;
import com.cg.mobilepurchase.util.DBUtil;

public class MobilePurchaseDaoImpl implements MobilePurchaseDao 
{
	Connection conn=null;
	//Statement st=null;
	//ResultSet rst=null;
	@Override
	public List<Mobiles> getAllMobiles() throws MobileException
	{
		List<Mobiles> mList=new ArrayList<>();
		conn=DBUtil.getConnection();
		Statement st;
		try
		{
			st = conn.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_ALL_MOBILES);
			while(rst.next())
			{
				Mobiles m=new Mobiles();
				m.setMobileId(rst.getLong("mobileId"));
				m.setMname(rst.getString("name"));
				m.setPrice(rst.getFloat("price"));
				m.setQuantity(rst.getInt("quantity"));
				mList.add(m);
			}
			
			
		}
		catch (SQLException e)
		{
			throw new MobileException("Problem in fetching mobile list:"+e.getMessage());
			
		}
		
		
		return mList;
	}

	@Override
	public Mobiles getMobile(long mid) throws MobileException
	{
		conn=DBUtil.getConnection();
		Mobiles m=null;
		PreparedStatement pst=null;
		try
		{
			pst=conn.prepareStatement(QueryMapper.SELECT_MOBILE);
			pst.setLong(1, mid);
			ResultSet rst=pst.executeQuery();
			if(rst.next())
			{
				m=new Mobiles();
				m.setMobileId(rst.getLong("mobileId"));
				m.setMname(rst.getString("name"));
				m.setPrice(rst.getFloat("price"));
				m.setQuantity(rst.getInt("quantity"));
			}
			else
			{
				throw new MobileException("Mobile not found ");
			}
			
		}
		catch (SQLException e)
		{
			throw new MobileException("Problem in fetching mobile:"+e.getMessage());
			
		}
		
		return m;
	}
	
	private long generatePurchaseId() throws MobileException
	{
		long pid=0;
		conn=DBUtil.getConnection();
		Statement st;
		try
		{
			st = conn.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			rst.next();
			pid=rst.getLong(1);
		}
		catch (SQLException e)
		{
			throw new MobileException("Problem in generating purchase Id"+e.getMessage());

		}
		return pid;
	}

	@Override
	public long insertPurchaseDetails(PurchaseDetails pDetails)
			throws MobileException
	{
		conn=DBUtil.getConnection();
		pDetails.setPurchaseId(generatePurchaseId());
		
		try
		{
			PreparedStatement pst=conn.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setLong(1, pDetails.getPurchaseId());
			pst.setString(2,pDetails.getCname());
			pst.setString(3,pDetails.getMailid());
			pst.setLong(4, pDetails.getPhoneno());
			pst.setDate(5, Date.valueOf(pDetails.getPurchasedate()));
			pst.setLong(6, pDetails.getMobileId());
			pst.executeUpdate();
		}
		
		catch (SQLException e) 
		{
			throw new MobileException("Problem in inserting purchase details"+e.getMessage());
		}
		
		return pDetails.getPurchaseId();
	}

}

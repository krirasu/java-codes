package com.cg.mobilepurchase.dto;

public class Mobiles
{
	private long mobileId;
	private String mname;
	private float price;
	private int quantity;
	public long getMobileId() {
		return mobileId;
	}
	public void setMobileId(long mobileId) {
		this.mobileId = mobileId;
	}
	
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Mobiles() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Mobiles(int mobileId, String name, float price, int quantity) {
		super();
		this.mobileId = mobileId;
		this.mname = name;
		this.price = price;
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Mobiles [mobileId=" + mobileId + ", mname=" + mname + ", price="
				+ price + ", quantity=" + quantity + "]";
	}
	
	
	
	
}

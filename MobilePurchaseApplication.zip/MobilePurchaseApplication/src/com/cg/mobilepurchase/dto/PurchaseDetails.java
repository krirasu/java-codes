package com.cg.mobilepurchase.dto;

import java.time.LocalDate;

public class PurchaseDetails
{
	private long purchaseId;
	private String cname;
	private String mailid;
	private long phoneno;
	private LocalDate purchasedate;
	private long mobileId;
	public PurchaseDetails() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public PurchaseDetails(long purchaseId, String cname, String mailid,
			long phoneno, LocalDate purchasedate,long mobileId) {
		super();
		this.purchaseId = purchaseId;
		this.cname = cname;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.purchasedate = purchasedate;
		this.mobileId=mobileId;
		
		
	}
	public long getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(long purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
	public LocalDate getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(LocalDate purchasedate) {
		this.purchasedate = purchasedate;
	}
	public long getMobileId() {
		return mobileId;
	}
	public void setMobileId(long mobileId) {
		this.mobileId = mobileId;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseId=" + purchaseId + ", cname=" + cname
				+ ", mailid=" + mailid + ", phoneno=" + phoneno
				+ ", purchasedate=" + purchasedate + ", mobileId=" + mobileId
				+ "]";
	}
	
	
}

package com.cg.mobilepurchase.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.mobilepurchase.dto.Mobiles;
import com.cg.mobilepurchase.dto.PurchaseDetails;
import com.cg.mobilepurchase.exception.MobileException;
import com.cg.mobilepurchase.service.MobileService;
import com.cg.mobilepurchase.service.MobileServiceImpl;


@WebServlet(urlPatterns={"/home","/buy","/purchase"})
public class PurchaseController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		String url=request.getServletPath();
		String targetUrl="";
		MobileService mSer=new MobileServiceImpl();
		switch(url)
		{
		
		case "/home":
			try
			{
				List<Mobiles> mList=mSer.getAllMobiles();
				request.setAttribute("mlist", mList);
				targetUrl="Home.jsp";
				
			}
			catch(MobileException e)
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
				
			}
			break;
		
		case "/buy":
			long mid=Long.parseLong(request.getParameter("mid"));
			try
			{
				Mobiles mob=mSer.getMobile(mid);
				HttpSession sess=request.getSession(true);
				sess.setAttribute("mob", mob);
				targetUrl="Insert.jsp";
				
			}
			catch (MobileException e)
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
		case "/purchase":
			PurchaseDetails pdDetails=new PurchaseDetails();
			pdDetails.setCname(request.getParameter("cname"));
			pdDetails.setMailid(request.getParameter("mail"));
			pdDetails.setPhoneno(Long.parseLong(request.getParameter("phoneno")));
			String dateStr=request.getParameter("pdate");
			DateTimeFormatter format=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			pdDetails.setPurchasedate(LocalDate.parse(dateStr,format));
			
			
			HttpSession sess=request.getSession(false);
			Mobiles mob=(Mobiles)sess.getAttribute("mob");
			pdDetails.setMobileId(mob.getMobileId());
			
			
			try
			{
				mSer.insertPurchaseDetails(pdDetails);
				request.setAttribute("pdetail", pdDetails);
				targetUrl="Success.jsp";
				
				
			}
			catch (MobileException e)
			{
				request.setAttribute("error",e.getMessage());
				targetUrl="Error.jsp";
			}
			
			break;
			
			
			
			
		}
		RequestDispatcher disp=request.getRequestDispatcher(targetUrl);
		disp.forward(request, response);
		
		
	}

}

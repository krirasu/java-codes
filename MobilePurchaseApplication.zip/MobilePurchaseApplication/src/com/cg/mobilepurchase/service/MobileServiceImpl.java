package com.cg.mobilepurchase.service;

import java.util.List;

import com.cg.mobilepurchase.dao.MobilePurchaseDao;
import com.cg.mobilepurchase.dao.MobilePurchaseDaoImpl;
import com.cg.mobilepurchase.dto.Mobiles;
import com.cg.mobilepurchase.dto.PurchaseDetails;
import com.cg.mobilepurchase.exception.MobileException;

public class MobileServiceImpl implements MobileService
{
	MobilePurchaseDao mDao=new MobilePurchaseDaoImpl();

	@Override
	public List<Mobiles> getAllMobiles() throws MobileException
	{
		
		return mDao.getAllMobiles();
	}

	@Override
	public Mobiles getMobile(long mid) throws MobileException
	{


		return mDao.getMobile(mid);
	}

	@Override
	public long insertPurchaseDetails(PurchaseDetails pDetails)
			throws MobileException
	{
		return mDao.insertPurchaseDetails(pDetails);
	}

}

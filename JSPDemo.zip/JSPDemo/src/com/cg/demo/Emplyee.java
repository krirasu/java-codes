package com.cg.demo;

public class Emplyee {
	private String ename;
	private int age;
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Emplyee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Emplyee(String ename, int age) {
		super();
		this.ename = ename;
		this.age = age;
	}
	
	

}

public class TestPersonInfo 
{
	public static void main(String[] args) 
	{
		Person p1 =new Person("Divya","Bharathi",'F',20,85.55f);
		System.out.println("Person details are: ");
		System.out.println("-------------------------");
		System.out.println(p1.dispPersonInfo());
	}
}



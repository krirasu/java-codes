public class Person
{
	private String firstName;
	private String lastName;
	private char gender;
	private int age;
	private float weight;
	
	public Person()
	{
		firstName="Unknown";
		lastName="Unknown";
		gender=' ';
		age=0;
		weight=0.0f;
	}
	public Person(String firstName,String lastName,char gender,int age,float weight)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.gender=gender;
		this.age=age;
		this.weight=weight;
	}
	public String dispPersonInfo()
	{
		return "First Name: "+firstName+"\n"+
			   "Last Name: "+lastName+"\n"+
			   "Gender: "+gender+"\n"+
			   "Age: "+age+"\n"+
			   "Weight"+weight;
	}
}



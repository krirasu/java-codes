import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class TestDeserializationDemo 
{
	public static void main(String[] args) 
	{
		
		Emp emp[]=new Emp[3];
		
		FileInputStream fis;
		try
		{
			fis=new FileInputStream("EmpData.obj");
			ObjectInputStream ois=new ObjectInputStream(fis);
			for(int i=0;i<3;i++)
			{
				emp[i]=(Emp)ois.readObject();
			System.out.println("Emp Object is read from a file"+emp[i]);
			}
		}
		catch (Exception e) 
		{			
			e.printStackTrace();
		}	
	}
}

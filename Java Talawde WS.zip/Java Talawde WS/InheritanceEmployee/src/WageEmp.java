
public class WageEmp extends Employee
{
	private int noOfHrs;
	private int ratePerHr;
	
	public WageEmp()
	{
		super();
	}
	
	public WageEmp(int empId,String empName,float empSal,int noOfHrs, int ratePerHr) 
	{
		super(empId,empName,empSal);
		this.noOfHrs = noOfHrs;
		this.ratePerHr = ratePerHr;
	}
	public float calcEmpBasicSal()
	{
		return super.calcEmpBasicSal()+(ratePerHr*noOfHrs*22);
	}
	public float calcEmpAnnulSal()
	{
		return calcEmpBasicSal()*12;
	}
}

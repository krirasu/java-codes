
public class TestInheritanceDemo 
{

	public static void main(String[] args) 
	{
	Employee krittika=new Employee(111,"Krittika R",1000.0f);
	WageEmp babitha=new WageEmp(112,"Babitha R",5000.0f,400,5);
	System.out.println(" Emp Info: "+krittika.dispEmpInfo());
	System.out.println(" Emp Monthly Salary: "+krittika.calcEmpBasicSal());
	System.out.println(" Emp Annual Salary : "+krittika.calcEmpAnnulSal());
	
	System.out.println(" Wage Emp Info: "+babitha.dispEmpInfo());
	System.out.println(" Wage Emp Monthly Salary: "+babitha.calcEmpBasicSal());
	System.out.println(" Wage Emp Annual Salary : "+babitha.calcEmpAnnulSal());
	
	SalesManager jyoti=new SalesManager(113,"Jyoti",5000.0f,7,500,5,0.2f);
	System.out.println(" Sales Manager Info: "+jyoti.dispEmpInfo());
	System.out.println(" Sales Manager Monthly Salary: "+jyoti.calcEmpBasicSal());
	System.out.println(" Sales Manager Annual Salary : "+jyoti.calcEmpAnnulSal());
	}
}

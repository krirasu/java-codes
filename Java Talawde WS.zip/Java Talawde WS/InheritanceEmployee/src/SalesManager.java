
public class SalesManager extends WageEmp
{
	private int sale;
	private float comm;
	
	public SalesManager()
	{
		super();
	}
	
	public SalesManager(int empId,String empName,float empSal,int noOfHrs, int ratePerHr,float comm,int sale) 
	{
		super(empId,empName,empSal,noOfHrs,ratePerHr);
		this.sale = sale;
		this.comm = comm;
	}
	public float calcEmpBasicSal()
	{
		return super.calcEmpBasicSal()+(sale*comm);
	}
	public float calcEmpAnnulSal()
	{
		return calcEmpBasicSal()*12;
	}
}

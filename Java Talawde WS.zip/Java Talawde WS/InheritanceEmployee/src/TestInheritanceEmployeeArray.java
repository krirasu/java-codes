import java.util.Scanner;
public class TestInheritanceEmployeeArray 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("How many Employees?");
		int empCount=sc.nextInt();
		Employee empArr[]=new Employee[empCount];
		int eId=0;
		String enm=null;
		int noOfHrs=0;
		int ratePerHr=0;
		float esl=0.0f;
		for(int i=0;i<empArr.length;i++)
		{
			System.out.println("Enter Emp Id: ");
			eId=sc.nextInt();
			System.out.println("Enter Emp Name: ");
			enm=sc.next();
			System.out.println("Enter Emp Salary: ");
			esl=sc.nextFloat();
			System.out.println("What type of Employee ?"+enm+" Is?"+"1:Emp \t 2:WageEmp \t 3:Sales Manager");
			System.out.println("Enter Choice");
			int choice=sc.nextInt();
			switch (choice)
			{
			case 1:empArr[i]=new Employee(eId,enm,esl);
			break;
			case 2: 
					System.out.println("Enter no. of hrs you worked");
					noOfHrs=sc.nextInt();
					System.out.println("Enter Rate per hour");
					ratePerHr=sc.nextInt();
					empArr[i]=new WageEmp(eId,enm,esl,noOfHrs,ratePerHr);
					break;
			default: System.out.println
					("Enter no. of hrs you worked");
					noOfHrs=sc.nextInt();
					System.out.println("Enter Rate per hour");
					ratePerHr=sc.nextInt();
					System.out.println
					("Enter Salesyou have done");
					int sale=sc.nextInt();
					System.out.println
					("Enter commission rate");
					float comm=sc.nextFloat();
					empArr[i]=new SalesManager(eId,enm,esl,noOfHrs,ratePerHr,comm,sale);
			}
		}
		System.out.println("**********************");
		for(int j=0;j<empArr.length;j++)
		{
			if(empArr[j] instanceof SalesManager)
			{
				System.out.println("Sales Manager :"+empArr[j].dispEmpInfo()+" Monthly Basic Salary: "+empArr[j].calcEmpBasicSal()+" Annual Salary: "+empArr[j].calcEmpAnnulSal());
			}
			else if(empArr[j] instanceof WageEmp)
			{
				System.out.println("Wage Manager :"+empArr[j].dispEmpInfo()+" Monthly Basic Salary: "+empArr[j].calcEmpBasicSal()+" Annual Salary: "+empArr[j].calcEmpAnnulSal());
			}
			else
			{
				System.out.println("Employee :"+empArr[j].dispEmpInfo()+" Monthly Basic Salary: "+empArr[j].calcEmpBasicSal()+" Annual Salary: "+empArr[j].calcEmpAnnulSal());
			}
		}
	}
}


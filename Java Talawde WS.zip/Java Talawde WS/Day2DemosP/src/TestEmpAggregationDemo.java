
public class TestEmpAggregationDemo 
{
	public static void main(String[] args)
	{
		Date vaiDOJ=new Date(01,04,2015);
		Date krittikaDOJ=new Date(13,12,2017);
		
		Employee vaishali=new Employee(112081,"Vaishali S",10000.0f,vaiDOJ);
		Employee krittika=new Employee(34567,"Krittika R",20000.0f,krittikaDOJ);
		
		System.out.println(vaishali.dispEmpInfo());
		System.out.println(krittika.dispEmpInfo());
	}
}

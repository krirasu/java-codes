import java.util.Scanner;
public class TestPhoneNumber {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		long phNo;
		System.out.println("Enter the Phone number: ");
		phNo=sc.nextLong();
		PhoneNumber ph1=new PhoneNumber("Divya","Bharathi",'F',phNo);
		
		System.out.println(" First Name:"+ph1.getFirstName());
		System.out.println(" Last Name:"+ph1.getLastName());
		System.out.println(" Gender :"+ph1.getGender());
		System.out.println(" Phone No :"+ph1.getPhoneNo());
	}
}

public class PhoneNumber 
{
	private String firstName;
	private String lastName;
	private char gender;
	private long phoneNo;
	
	public PhoneNumber()
	{
	}
	public String getFirstName()
	{
		return firstName;
	}
	public String getLastName()
	{
		return lastName;
	}
	public char getGender()
	{
		return gender;
	}
	public long getPhoneNo()
	{
		return phoneNo;
	}
	public void setFirstName(String firstName)
	{
		this.firstName=firstName;
	}
	public void setLastName(String lastName)
	{
		this.lastName=lastName;
	}
	public void setGender(char gender)
	{
		this.gender=gender;
	}
	public void setPhoneNo(long phoneNo)
	{
		this.phoneNo=phoneNo;
	}
	public PhoneNumber(String firstName, String lastName, char gender,
			long phoneNo) 
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.phoneNo = phoneNo;
	}
	
}


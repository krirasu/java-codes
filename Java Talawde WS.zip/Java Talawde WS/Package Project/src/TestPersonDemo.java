public class TestPersonDemo 
{
	public static void main(String[] args) 
	{
		Person p1=new Person("Vaishali S","CBH78GOP",10);
		Person p2=new Person("Krittika R","GJCMG56KL",24);
		Person p3=new Person("Vaishali S","CBH78GOP",10);
		
		Integer i1=new Integer(20);
		Integer i2=new Integer(30);
		Integer i3=new Integer(20);
		
		System.out.println("i1="+i1);
		System.out.println("i2="+i2);
		System.out.println("i3="+i3);
		
		if(i1.equals(i3))
		{
			System.out.println("Hey we are same");
		}
		else
		{
			System.out.println("We are different");
		}
		System.out.println("Hashcode Of p1 "+p1.hashCode());
		System.out.println("Hashcode Of p2 "+p2.hashCode());
		System.out.println("Hashcode Of p3 "+p3.hashCode());
		
		System.out.println("Hashcode Of i1 "+i1.hashCode());
		System.out.println("Hashcode Of i2 "+i2.hashCode());
		System.out.println("Hashcode Of i3 "+i3.hashCode());
	}
}

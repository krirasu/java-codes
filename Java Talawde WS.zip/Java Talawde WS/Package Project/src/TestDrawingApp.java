public class TestDrawingApp 
{
	public static void main(String[] args) 
	{
		Shape shape1=new Circle(5);
		Shape shape2=new Circle(2);
		Shape shape3=new Sphere(5);
		
		System.out.println("Area of Circle: "+shape1.calcArea());
		System.out.println("Perimeter of Circle: "+shape1.calcPerimeter());
		System.out.println("Area of Circle: "+shape2.calcArea());
		System.out.println("Perimeter of Circle: "+shape2.calcPerimeter());
		System.out.println("Volume of Sphere: "+shape3.calcArea());
		System.out.println(" Surface Area of Sphere: "+shape3.calcPerimeter());
	}

}

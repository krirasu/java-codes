
public class AcceptNumber 
{
	public static void main (String ar[]) 
	{
		int number=Integer.parseInt(ar[0]);
		if(number>=0)
		{
			System.out.println("It is a positive number");
		}
		else
		{
			System.out.println("It is a negative number");
		}
	}
}

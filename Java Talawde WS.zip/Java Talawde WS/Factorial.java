public class Factorial
{
public static void main(String ar[])
	{
	 int number=Integer.parseInt(ar[0]);
	 int factorial=1;
	 int index;
	 for(index=1;index<=number;index++)
	 {
	 factorial=factorial*index;
	 }
	 System.out.println("Factorial of the number is:"+factorial);
	 }
}
public class TestPersonGetSet 
{
	public static void main(String[] args) 
	{
		PersonGetSet p1=new PersonGetSet();
		p1.setFirstName("Divya");
		p1.setLastName("Bharathi");
		p1.setGender('F');
		
		System.out.println(" First Name:"+p1.getFirstName());
		System.out.println(" Last Name:"+p1.getLastName());
		System.out.println(" Gender :"+p1.getGender());
		
	}
}

import java.util.Scanner;
public class TestEmployeeArrayDemo 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int empId=0;
		String empName=null;
		float empSal=0.0f;
		char empGen=' ';
		String gen;
		int count;
		System.out.println("Enter no. of variables:");
		count=sc.nextInt();
		Employee allEmps[]=new Employee[count];
		
		for(int i=0;i<count;i++)
		{
			System.out.println("Enter Employee Id :");
			empId=sc.nextInt();
			
			System.out.println("Enter Employee Name :");
			empName=sc.next();
			
			System.out.println("Enter Employee Salary :");
			empSal=sc.nextFloat();
			
			System.out.println("Enter Employee Gender :");
			gen=sc.next();
			empGen=gen.charAt(0);
			
			allEmps[i]=new Employee(empId,empName,empSal,empGen);
		 }
		
			for(int j=0;j<count;j++)
			{
			System.out.println(allEmps[j].dispEmployeeInfo());
			}
	}
}

public class TestDateDemo {

	public static void main(String[] args) 
	{
		Date krittikaDOJ=new Date(13,12,2017);
		System.out.println("Krittika DOJ is: "+krittikaDOJ.dispDate());
		
		Date vaiDOJ=new Date(04,03,2013);
		System.out.println("Vaishali DOJ is: "+vaiDOJ.dispDate());
		
		Date unknownPerson=new Date();
		System.out.println("Unknown person DOJ is: "+unknownPerson.dispDate());
	}

}

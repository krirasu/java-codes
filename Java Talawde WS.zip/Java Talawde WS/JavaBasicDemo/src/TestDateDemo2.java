import java.util.Scanner;
public class TestDateDemo2 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		for(int i=1;i<3;i++)
		{
			System.out.println("Enter Name :");
			String name=sc.next();
			
			System.out.println("Enter Date :");
			int dayOfDOJ=sc.nextInt();
			
			System.out.println("Enter Month :");
			int monthOfDOJ=sc.nextInt();
			
			System.out.println("Enter Year :");
			int yearOfDOJ=sc.nextInt();
			
			Date krittikaDOJ=new Date(dayOfDOJ,monthOfDOJ,yearOfDOJ);
			System.out.println(name+" Your DOJ is: "+krittikaDOJ.dispDate());
		}
	}
}

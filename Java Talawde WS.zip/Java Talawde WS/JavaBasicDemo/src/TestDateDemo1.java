import java.util.Scanner;
public class TestDateDemo1 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Day :");
		int dayOfDOJ=sc.nextInt();
		
		System.out.println("Enter Month :");
		int monthOfDOJ=sc.nextInt();
		
		System.out.println("Enter Year :");
		int yearOfDOJ=sc.nextInt();
		
		Date krittikaDOJ=new Date(dayOfDOJ,monthOfDOJ,yearOfDOJ);
		System.out.println("Your DOJ : "+krittikaDOJ.dispDate());
		
		System.out.println("********************");
		
		System.out.println("Enter Day :");
		dayOfDOJ=sc.nextInt();
		
		System.out.println("Enter Month :");
		monthOfDOJ=sc.nextInt();
		
		System.out.println("Enter Year :");
		yearOfDOJ=sc.nextInt();
		
		Date vaiDOJ=new Date(dayOfDOJ,monthOfDOJ,yearOfDOJ);
		System.out.println("Your DOJ : "+vaiDOJ.dispDate());
	}
}

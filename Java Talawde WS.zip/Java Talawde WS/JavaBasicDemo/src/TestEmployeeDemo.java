
public class TestEmployeeDemo 
{
	public static void main(String[] args) 
	{
		Employee emp1 =new Employee(1001,"Krittika",15000.0f,'F');
		System.out.println("Employee details are: "+emp1.dispEmployeeInfo());
		
		Employee emp2 =new Employee(1002,"Babitha",17000.0f,'F');
		System.out.println("Employee details are: "+emp2.dispEmployeeInfo());
		
		Employee emp3 =new Employee(1003,"Jyoti",20000.0f,'F');
		System.out.println("Employee details are: "+emp3.dispEmployeeInfo());
		
		Employee emp4 =new Employee();
		System.out.println("Employee details are: "+emp4.dispEmployeeInfo());
	}
}


public class Employee 
{
	private int empId;
	private String empName;
	private float empSal;
	private char empGen;
	public Employee()
	{
		empId=0;
		empName="Unknown";
		empSal=0.0f;
		empGen=' ';
	}
	public Employee(int eid,String ename,float esal,char egender)
	{
		empId=eid;
		empName=ename;
		empSal=esal;
		empGen=egender;
	}
	public String dispEmployeeInfo()
	{
		return empId+" "+empName+" "+empSal+" "+empGen;
	}
	
	public float calcBasicSal()
	{
		return empSal;
	}
}

public class Tablet extends Medicine 
{
	public Tablet()
	{
		super();
	}
	
	public Tablet(String medName,String cmpName,String medDate,float price) 
	{
		super(medName,cmpName,medDate,price);
	}
	public String dispMedInfo()
	{
		return super.dispMedInfo()+"\nIt is stored in cold place";
	}
}

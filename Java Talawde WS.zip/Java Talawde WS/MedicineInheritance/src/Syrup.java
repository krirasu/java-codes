public class Syrup extends Medicine
{
	public Syrup()
	{
		super();
	}
	public Syrup(String medName,String cmpName,String medDate,float price) 
	{
		super(medName,cmpName,medDate,price);
	}
	public String dispMedInfo()
	{
		return super.dispMedInfo()+"\nShake well before use";
	}
}

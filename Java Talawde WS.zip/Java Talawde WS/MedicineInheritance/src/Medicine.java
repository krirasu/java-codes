public class Medicine 
{
	private String medName;
	private String cmpName;
	private String medDate;
	private float price;
	public Medicine()
	{
	};
	
	public Medicine(String medName,String cmpName,String medDate,float price)
	{
		this.medName=medName;
		this.cmpName=cmpName;
		this.medDate=medDate;
		this.price=price;
	}
	public String dispMedInfo()
	{
		return "Medicine Name "+medName+"Company Name: "+cmpName+"Medicine expiry date: "+medDate+"Price of medicine: "+price;
	}
}

public class Ointment extends Medicine
{
	public Ointment()
	{
		super();
	}
	public Ointment(String medName,String cmpName,String medDate,float price) 
	{
		super(medName,cmpName,medDate,price);
	}
	public String dispMedInfo()
	{
		return super.dispMedInfo()+"\nIt is for external use only";
	}
}

import java.util.Scanner;
public class TestMedicineDemo
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("How many Medicines?");
		int medCount=sc.nextInt();
		Medicine medArr[]=new Medicine[medCount];
		String mName=null;
		String cName=null;
		String mDate=null;
		int mPrice=0;
		for(int i=0;i<medArr.length;i++)
		{
			System.out.println("Enter Medicine Name: ");
			mName=sc.next();
			System.out.println("Enter Medicine company Name: ");
			cName=sc.next();
			System.out.println("Enter Medicine expiry date: ");
			mDate=sc.next();
			System.out.println("Enter Medicine price: ");
			mPrice=sc.nextInt();
			System.out.println("What type of Medicine "+mName+" Is?"+" 1:Tablet \t 2:Ointment \t 3:Syrup");
			System.out.println("Enter Choice");
			int choice=sc.nextInt();
			switch (choice)
			{
			case 1:medArr[i]=new Tablet(mName,cName,mDate,mPrice);
			break;
			case 2: 
				medArr[i]=new Ointment(mName,cName,mDate,mPrice);
					break;
			default: medArr[i]=new Syrup(mName,cName,mDate,mPrice);
			break;
			}
		}
		System.out.println("**********************");
		for(int j=0;j<medArr.length;j++)
		{
			if(medArr[j] instanceof Tablet)
			{
				System.out.println("Tablet :"+medArr[j].dispMedInfo());
			}
			else if(medArr[j] instanceof Ointment)
			{
				System.out.println("Ointment :"+medArr[j].dispMedInfo());
			}
			else
			{
				System.out.println("Syrup:"+medArr[j].dispMedInfo());
			}
		}
	}
}


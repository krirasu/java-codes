public interface Printable
{
	static double PI=3.14566;
	void print();
}

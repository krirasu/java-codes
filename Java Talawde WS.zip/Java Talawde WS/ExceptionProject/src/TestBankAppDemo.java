import java.util.Scanner;
public class TestBankAppDemo 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int currentBalance=60000;
		System.out.println("Enter the withdraw amount");
		int withdrawAmt=sc.nextInt();
		if(withdrawAmt<currentBalance)
		{
			System.out.println("OK you have sufficient balance,you can withdraw the amount");
		}
		else
		{
			try {
				throw new LowBalanceException
				("Please check balance of your account");
			    }
			catch (LowBalanceException e) 
			{
				System.out.println("Insufficient balance in your account");
			}
		}

	}

}

public class TestStaticempDemo 
		{	
			static
			{
				System.out.println("This is TestStaticempDemo static block");
			}
			public static void main(String[] args) 
			{	
				System.out.println("Main starts here");
				Emp e1=new Emp(111,"Vaishali",1000.0f);
				Emp e2=new Emp(112,"Krittika",2000.0f);
				Emp e3=new Emp(113,"Babitha",3000.0f);
				System.out.println(e1.dispEmpInfo());
				System.out.println(e2.dispEmpInfo());
				System.out.println(e3.dispEmpInfo());
				Emp.getCount();
				show();
			}
			
			private static void show()
			{
				System.out.println("Static is used to call instances");
			}
		}

	

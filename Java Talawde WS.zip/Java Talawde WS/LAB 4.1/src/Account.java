
public class Account extends Person
{
	private long accNUm;
	private double accBalance;
	private Person accHolder;
	
	public Account()
	{
	}

	public Account(long accNUm, double accBalance, Person accHolder) 
	{
		this.accNUm = accNUm;
		this.accBalance = accBalance;
		this.accHolder = accHolder;
	}

	public long getAccNUm() 
	{
		return accNUm;
	}

	public void setAccNUm(long accNUm) 
	{
		this.accNUm = accNUm;
	}

	public double getAccBalance() 
	{
		return accBalance;
	}

	public void setAccBalance(double accBalance) 
	{
		this.accBalance = accBalance;
	}

	public Person getAccHolder() 
	{
		return accHolder;
	}

	public void setAccHolder(Person accHolder) 
	{
		this.accHolder = accHolder;
	}
	public void deposit(double amount)
	{
		accBalance = accBalance+amount;
	}
	public void withdraw(double amount)
	{
		accBalance = accBalance-amount;
	}
}

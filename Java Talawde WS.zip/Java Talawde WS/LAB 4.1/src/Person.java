public class Person 
{
	private String pName;
	private float pAge;
	
	public String getpName() 
	{
		return pName;
	}
	public void setpName(String pName) 
	{
		this.pName = pName;
	}
	public float getpAge() 
	{
		return pAge;
	}
	public void setpAge(float pAge) 
	{
		this.pAge = pAge;
	}
	public Person()
	{
	
	}
	public Person(String pName, float pAge) 
	{
		super();
		this.pName = pName;
		this.pAge = pAge;
	}
	@Override
	public String toString() 
	{
		return "Person [pName=" + pName + ", pAge=" + pAge + "]";
	}
}

import java.util.Scanner;
enum Gender
{
	M,F;
}
public class EnumTest 
{
	public static void main(String[] args)
	{
				Scanner sc=new Scanner(System.in);
				long phNo;
				System.out.println("Enter the Phone number: ");
				phNo=sc.nextLong();
				Enum ph1=new Enum("Divya","Bharathi",phNo);
				Gender empGen=Gender.F;
				ph1.setGen(empGen);
				
				System.out.println("Employee gender is: "+ph1.getGen());
				System.out.println(" First Name:"+ph1.getFirstName());
				System.out.println(" Last Name:"+ph1.getLastName());
				System.out.println(" Phone No :"+ph1.getPhoneNo());
	}
}

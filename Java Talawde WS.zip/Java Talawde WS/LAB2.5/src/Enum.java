public class Enum
{
	private String firstName;
	private String lastName;
	private long phoneNo;
	private Gender gen;
	public Enum()
	{
	}
	public String getFirstName()
	{
		return firstName;
	}
	public String getLastName()
	{
		return lastName;
	}
	public long getPhoneNo()
	{
		return phoneNo;
	}
	public void setFirstName(String firstName)
	{
		this.firstName=firstName;
	}
	public void setLastName(String lastName)
	{
		this.lastName=lastName;
	}
	public void setPhoneNo(long phoneNo)
	{
		this.phoneNo=phoneNo;
	}
	
	public Gender getGen() 
	{
		return gen;
	}
	public void setGen(Gender gen) 
	{
		this.gen = gen;
	}
	public Enum(String firstName, String lastName,long phoneNo) 
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNo = phoneNo;
	}
}


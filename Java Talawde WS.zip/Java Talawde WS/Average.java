public class Average
{
	public static void main(String ar[])
	{
		float average;
		float sum=0;
		int totalNumbers=Integer.parseInt(ar[0]);
		int index=0;
		for(index=0;index<totalNumbers;index++)
		{
			sum=sum+Integer.parseInt(ar[index]);
		}
		average = sum / totalNumbers;
		System.out.println("Average of the number is:"+average);
	 }
}
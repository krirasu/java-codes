public class Greet
{
public static void main(String ar[])
	{
	String firstName=ar[0];
	int sal=Integer.parseInt(ar[1]);	
	System.out.println("Welcome to Capgemini"+firstName);
	}
}

class WishMe
{
public static void main(String ar[])
	{
	String lastName="Ranganathan";	
	System.out.println("Happy New Year "+lastName);
	}
}
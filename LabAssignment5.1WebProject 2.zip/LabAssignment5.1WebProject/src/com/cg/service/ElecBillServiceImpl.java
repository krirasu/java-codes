package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.ElecBillDao;
import com.cg.dao.ElecBillDaoImpl;
import com.cg.dto.ElectricityBill;

public class ElecBillServiceImpl implements ElecBillService
{
	ElecBillDao elecBillDao=null;
	public ElecBillServiceImpl()
	{
		elecBillDao=new ElecBillDaoImpl();
	}
	@Override
	public int addBillDetails(ElectricityBill elecBill) throws Exception 
	{

		return elecBillDao.addBillDetails(elecBill);
	}

	@Override
	public int generateBillNumber() throws Exception
	{

		return elecBillDao.generateBillNumber();
	}

	@Override
	public boolean validateLMonMeterReading(float lMonMeterReading)
			throws Exception
	{
		if(lMonMeterReading<0)
		{
			return false;
		}
		else
		{
			return true;
		}

	}

	@Override
	public boolean validateCMonMeterReading(float cMonMeterReading, float lMonMeterReading)
			throws Exception 
	{
		if(cMonMeterReading<0 && (cMonMeterReading<lMonMeterReading))
		{
			return false;
		}
		else
		{
			return true;
		}


	}

//	@Override
//	public boolean validateMeterReading(float lMonMeterReading,float cMonMeterReading)
//			throws Exception
//	{
//		if(cMonMeterReading<lMonMeterReading)
//		{
//			return false;
//		}
//		else
//		{
//			return true;
//		}
	}
	public float calcUnitConsumed(float lMonMeterReading,float cMonMeterReading)
	{
		float unitConsumed=cMonMeterReading-lMonMeterReading;
		return unitConsumed;
	}
	public float calcNetAmount(float unitConsumed)
	{
		final int fixedCharge=100;
		float netAmount=(float) (unitConsumed*1.15+fixedCharge);
		return netAmount;
	}


	@Override
	public boolean validateConsumerNumber(int consumerNumber) throws Exception
	{
		int flag=0;
		ArrayList<Integer> consuNoList=elecBillDao.getConsumerNo();
		for(int tempConsNo :consuNoList)
		{
			if(consumerNumber==tempConsNo)
			{
				flag=1;
			}

		}
		if(flag==1)
		{
			return true;
		}

		else
		{
			return false;
		}

	}
	@Override
	public String getConsumerName(int consumerNumber) throws Exception
	{

		return elecBillDao.getConsumerName(consumerNumber);
	}

}

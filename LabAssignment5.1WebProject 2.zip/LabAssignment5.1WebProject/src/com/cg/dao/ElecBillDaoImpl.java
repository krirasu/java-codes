package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.dto.ElectricityBill;
import com.cg.util.DBUtil;

public class ElecBillDaoImpl implements ElecBillDao
{
	Connection con=null;
	PreparedStatement pst=null;
	Statement st=null;
	ResultSet rs=null;
	int dataAdded=0;
	@Override
	public int addBillDetails(ElectricityBill elecBill) throws Exception 
	{
		con=DBUtil.getCon();
		String insertQry="INSERT INTO BillDetails VALUES(?,?,?,?,?,sysdate)";
		pst=con.prepareStatement(insertQry);
		pst.setInt(1, generateBillNumber());
		pst.setFloat(2, elecBill.getConsumerNumber());
		pst.setFloat(3, elecBill.getCurrMonthReading());
		pst.setFloat(4, elecBill.getUnitConsumed());
		pst.setFloat(5,elecBill.getNetAmount());
		dataAdded=pst.executeUpdate();
		return dataAdded;
	}
	public int generateBillNumber() throws Exception
	{		
		String qry="Select seq_bill_num.NEXTVAL FROM DUAL";
		int generatedVal=0;
		
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		
		
		return generatedVal;
	}
	@Override
	public ArrayList<Integer> getConsumerNo() throws Exception
	{
		ArrayList<Integer> consuNoList=new ArrayList<Integer>();
		String qry="SELECT consumer_num FROM Consumers";
		int generatedConsuNo=0;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			
			while(rs.next())
			{
				generatedConsuNo=rs.getInt(1);
				consuNoList.add(generatedConsuNo);
			}
			
			
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		return consuNoList;
	}
	@Override
	public String getConsumerName(int consumerNumber) throws Exception
	{
		String qry="SELECT consumer_name FROM Consumers where consumer_num=?";
		String consumerName=null;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(qry);
			pst.setInt(1, consumerNumber);
			rs=pst.executeQuery();
			rs.next();
			consumerName=rs.getString("consumer_name");
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		return consumerName;
	}

}

package com.cg.util;

import java.sql.Connection;
import java.sql.SQLException;
import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class DBUtil
{
 
	
	public static Connection getCon() throws SQLException
	{
		Connection con=null;
		 InitialContext context;
		try 
		{
			context=new InitialContext();
			DataSource ds=(DataSource)context.lookup("java:/jdbc/OracleDS");
			con=ds.getConnection();
		} 
		catch (NamingException e) 
		{
			e.printStackTrace();
		}
		return con;
	}
}
